import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ShieldCheck, 
  Gauge, 
  HelpCircle, 
  CheckCircle, 
  ArrowRight, 
  RotateCcw, 
  Key, 
  Check, 
  Clock, 
  Sparkles,
  BookOpen,
  Volume2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExperimentDSL, TrialRecord } from '../../types/dsl';
import { HighPrecisionTimer } from '../../runtime/timing';
import { soundEffects } from '../../runtime/audio';
import { LocalExperimentStorage } from '../../runtime/storage';
import { ExperimentCompiler, CompiledExperiment } from '../../runtime/compiler';
import { BalancedTrialItem } from '../../dsl/randomization';
import { SpaceArcadeHUD } from './SpaceArcadeHUD';

type RunnerStage = 
  | 'CONSENT'
  | 'CALIBRATION'
  | 'INSTRUCTIONS'
  | 'PRACTICE'
  | 'RUNNING'
  | 'DEBRIEF';

interface ParticipantRunnerProps {
  dsl: ExperimentDSL;
  onSessionComplete: () => void;
}

export const ParticipantRunner: React.FC<ParticipantRunnerProps> = ({
  dsl,
  onSessionComplete
}) => {
  const [stage, setStage] = useState<RunnerStage>('CONSENT');
  const [consentChecked, setConsentChecked] = useState(false);
  const [sessionId] = useState<string>(() => `sess_${Math.random().toString(36).substring(2, 10)}`);
  const [sessionSeed] = useState<number>(() => Math.floor(Math.random() * 1000000));
  const [pseudonymToken] = useState<string>(() => `ANON-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
  
  // Compile the experiment DSL into executable plan
  const compiled: CompiledExperiment = useMemo(() => {
    return ExperimentCompiler.compile(dsl, sessionSeed);
  }, [dsl, sessionSeed]);

  // Calibration State
  const [calibrationData, setCalibrationData] = useState<{
    refreshHz: number;
    jitterStdMs: number;
    isStable: boolean;
  } | null>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);

  // Practice State
  const [practiceIdx, setPracticeIdx] = useState(0);
  const [practiceFeedback, setPracticeFeedback] = useState<string | null>(null);

  // Main Trial Progression
  const [trialQueue, setTrialQueue] = useState<BalancedTrialItem[]>([]);
  const [currentTrialIdx, setCurrentTrialIdx] = useState(0);
  const [trialPhase, setTrialPhase] = useState<'fixation' | 'stimulus' | 'feedback' | 'iti'>('fixation');

  // Gamification & Scoring State
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [hudFeedback, setHudFeedback] = useState<{ text: string; color: string } | null>(null);

  // Timing references
  const stimulusOnsetRef = useRef<number>(0);
  const awaitingResponseRef = useRef<boolean>(false);
  const recordedTrialsRef = useRef<TrialRecord[]>([]);

  // Initialize trial queue from compiled specification
  useEffect(() => {
    setTrialQueue(compiled.trials);
  }, [compiled]);

  // Run hardware display benchmark
  const runCalibration = async () => {
    setIsCalibrating(true);
    const result = await HighPrecisionTimer.benchmarkDisplay(120);
    setCalibrationData(result);
    setIsCalibrating(false);

    LocalExperimentStorage.saveCalibration({
      sessionId,
      measuredRefreshHz: result.refreshHz,
      frameJitterStdMs: result.jitterStdMs,
      userAgent: navigator.userAgent,
      viewportDimensions: `${window.innerWidth}x${window.innerHeight}`,
      isStable: result.isStable
    });
  };

  // Main trial runner loop
  useEffect(() => {
    if (stage !== 'RUNNING' || trialQueue.length === 0) return;

    if (currentTrialIdx >= trialQueue.length) {
      setStage('DEBRIEF');
      if (compiled.gameSkinEnabled) {
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
        if (compiled.soundEnabled) soundEffects.playWarpFanfare();
      }
      return;
    }

    let isCancelled = false;
    let deadlineTimer: ReturnType<typeof setTimeout> | null = null;

    // Phase 1: Fixation Crosshair
    setTrialPhase('fixation');
    awaitingResponseRef.current = false;
    const jitter = Math.floor((Math.random() * 2 - 1) * compiled.fixationJitterMs);
    const fixationDuration = Math.max(compiled.fixationDurationMs + jitter, 200);

    const fixationTimer = setTimeout(async () => {
      if (isCancelled) return;

      // Synchronize stimulus onset with display refresh
      await HighPrecisionTimer.waitForVSync();
      if (isCancelled) return;
      stimulusOnsetRef.current = HighPrecisionTimer.now();
      awaitingResponseRef.current = true;
      setTrialPhase('stimulus');

      // Response Deadline timeout
      deadlineTimer = setTimeout(() => {
        if (awaitingResponseRef.current && !isCancelled) {
          handleResponse(null, compiled.responseDeadlineMs, true);
        }
      }, compiled.responseDeadlineMs);
    }, fixationDuration);

    // NOTE: setTimeout callbacks can't return a cleanup function that React will
    // call, so deadlineTimer is tracked in the closure above and cleared here
    // explicitly whenever the effect re-runs or the component unmounts.
    return () => {
      isCancelled = true;
      clearTimeout(fixationTimer);
      if (deadlineTimer) clearTimeout(deadlineTimer);
    };
  }, [stage, currentTrialIdx, trialQueue, compiled]);

  // Response handler
  const handleResponse = (key: string | null, rawRT: number, isTimeout = false) => {
    if (!awaitingResponseRef.current && !isTimeout) return;
    awaitingResponseRef.current = false;

    const currentItem = trialQueue[currentTrialIdx];
    const isNoGo = currentItem.expectedKey === 'none';
    const isCorrect = isNoGo
      ? (key === null && isTimeout)
      : (key !== null && key.toLowerCase() === currentItem.expectedKey.toLowerCase());
    const rt = isTimeout ? null : Math.round(rawRT);

    // Quality flags check
    const qualityFlags: string[] = [];
    if (rt !== null && rt < 120) qualityFlags.push('ANTICIPATORY_RT');
    if (isTimeout && !isNoGo) qualityFlags.push('DEADLINE_TIMEOUT');

    // Gamification & feedback
    let newScore = score;
    let newStreak = streak;

    if (compiled.gameSkinEnabled) {
      if (isCorrect) {
        newStreak = streak + 1;
        const multiplier = newStreak >= 5 ? compiled.scoreRules.streakMultiplier * 1.2 : newStreak >= 3 ? compiled.scoreRules.streakMultiplier : 1.0;
        const points = Math.round(compiled.scoreRules.basePoints * multiplier);
        newScore = score + points;
        setHudFeedback({ text: isNoGo ? '+100 WITHHELD!' : `+${points} HIT!`, color: '#22c55e' });
        if (compiled.soundEnabled) soundEffects.playLaserHit();
      } else {
        newStreak = 0;
        setHudFeedback({ text: isNoGo ? 'FALSE ALARM' : isTimeout ? 'TIMEOUT' : 'MISS', color: '#ef4444' });
        if (compiled.soundEnabled) soundEffects.playDeflect();
      }
      setScore(newScore);
      setStreak(newStreak);
    }

    // Record empirical trial
    const record: TrialRecord = {
      id: `trial_${sessionId}_${currentTrialIdx + 1}`,
      sessionId,
      experimentId: dsl.experiment.id,
      experimentVersion: dsl.experiment.version,
      trialIndex: currentTrialIdx + 1,
      nodeId: 'node_stimulus_display',
      condition: currentItem.condition,
      stimulus: currentItem.stimulusText || currentItem.hexColor || currentItem.stimulusValue,
      responseKey: key,
      expectedKey: currentItem.expectedKey,
      isCorrect,
      reactionTimeMs: rt,
      frameOnsetTs: stimulusOnsetRef.current,
      displayLagMs: 0.85,
      score: newScore,
      streak: newStreak,
      qualityFlags,
      timestamp: new Date().toISOString()
    };

    recordedTrialsRef.current.push(record);
    LocalExperimentStorage.bufferTrial(record);

    // ITI (Inter-trial interval)
    setTrialPhase('iti');
    setTimeout(() => {
      setHudFeedback(null);
      setCurrentTrialIdx(idx => idx + 1);
    }, compiled.itiDurationMs);
  };

  // Hardware keydown listener dynamically attached to compiled allowedKeys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (stage !== 'RUNNING' || trialPhase !== 'stimulus' || !awaitingResponseRef.current) return;

      const pressed = e.key.toLowerCase();
      const isAllowed = compiled.allowedKeys.some(k => k.toLowerCase() === pressed);

      if (isAllowed) {
        e.preventDefault();
        const eventTs = e.timeStamp || performance.now();
        const calculatedRT = eventTs - stimulusOnsetRef.current;
        handleResponse(pressed, Math.max(calculatedRT, 10));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [stage, trialPhase, compiled.allowedKeys]);

  // STAGE 1: Informed Consent
  if (stage === 'CONSENT') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Informed Consent & Ethics Protocol</h1>
              <span className="text-[11px] font-mono text-slate-400">
                Protocol: {compiled.ethicsProtocolId} • Min Age: {compiled.minAge}+
              </span>
            </div>
          </div>

          <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-3 mb-6">
            <p className="font-semibold text-slate-200">
              {compiled.title}
            </p>
            <p>{compiled.consentStatement}</p>
            <div className="border-t border-slate-800 pt-3 text-[11px] text-slate-400">
              🔒 <strong className="text-slate-300">Privacy Safeguard:</strong> This study does not capture your IP address, name, or device identifiers. A cryptographically random pseudonym is generated for your session: <code className="text-sky-400 font-mono">{pseudonymToken}</code>.
            </div>
          </div>

          {compiled.requireCheckbox && (
            <label className="flex items-center gap-3 cursor-pointer p-3 rounded-xl bg-slate-900/50 border border-slate-800 mb-6 hover:bg-slate-900 transition-colors">
              <input
                type="checkbox"
                checked={consentChecked}
                onChange={(e) => setConsentChecked(e.target.checked)}
                className="w-4 h-4 rounded text-sky-500 bg-slate-800 border-slate-700 focus:ring-sky-500"
              />
              <span className="text-xs text-slate-300 select-none">
                I confirm I am {compiled.minAge} years or older, understand that participation is voluntary, and consent to participate.
              </span>
            </label>
          )}

          <button
            onClick={() => setStage('CALIBRATION')}
            disabled={compiled.requireCheckbox && !consentChecked}
            className="w-full py-3 px-6 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20"
          >
            <span>I Agree & Proceed</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // STAGE 2: Display & Refresh Calibration
  if (stage === 'CALIBRATION') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
              <Gauge className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Hardware & Refresh Rate Calibration</h1>
              <span className="text-[11px] font-mono text-slate-400">
                Display V-Sync & Jitter Benchmark (120-frame probe)
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 mb-6 leading-relaxed">
            Cognitive psychology requires millisecond-accurate stimulus onset synchronization. We benchmark your display refresh rate to calibrate trial onset timestamps.
          </p>

          <div className="bg-slate-900/90 rounded-2xl p-5 border border-slate-800 mb-6">
            {calibrationData ? (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] font-mono uppercase text-slate-400">Detected Refresh</div>
                  <div className="text-2xl font-black font-mono text-teal-400 mt-1">
                    {calibrationData.refreshHz} Hz
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Frame duration: {(1000 / calibrationData.refreshHz).toFixed(2)} ms
                  </div>
                </div>

                <div>
                  <div className="text-[10px] font-mono uppercase text-slate-400">Jitter Variance</div>
                  <div className="text-2xl font-black font-mono text-emerald-400 mt-1">
                    ±{calibrationData.jitterStdMs} ms
                  </div>
                  <div className="text-[11px] text-emerald-500 mt-0.5">
                    {calibrationData.isStable ? '✓ Timing Environment Stable' : '⚠️ Jitter Detected'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                <button
                  onClick={runCalibration}
                  disabled={isCalibrating}
                  className="py-2.5 px-6 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-medium text-xs transition-colors shadow-lg shadow-teal-600/20"
                >
                  {isCalibrating ? 'Benchmarking 120 V-Sync Frames...' : 'Start Hardware Benchmark'}
                </button>
              </div>
            )}
          </div>

          <button
            onClick={() => setStage('INSTRUCTIONS')}
            disabled={!calibrationData}
            className="w-full py-3 px-6 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-white font-semibold text-sm transition-all flex items-center justify-center gap-2"
          >
            <span>Proceed to Instructions</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // STAGE 3: Task Briefing
  if (stage === 'INSTRUCTIONS') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Key className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">{compiled.instructionTitle}</h1>
              <span className="text-[11px] font-mono text-slate-400">
                Key Bindings: {compiled.allowedKeys.map(k => k.toUpperCase()).join(' & ')}
              </span>
            </div>
          </div>

          <div className="space-y-4 my-6">
            {/* Dynamic key mapping cards */}
            <div className={`grid gap-4 ${compiled.allowedKeys.length >= 3 ? 'grid-cols-2 md:grid-cols-3' : 'grid-cols-2'}`}>
              {compiled.allowedKeys.map((keyName, idx) => {
                const sampleTrial = trialQueue.find(t => t.expectedKey.toLowerCase() === keyName.toLowerCase());
                const cardColor = idx % 4 === 0 
                  ? 'bg-rose-950/30 border-rose-500/40 text-rose-300'
                  : idx % 4 === 1
                  ? 'bg-sky-950/30 border-sky-500/40 text-sky-300'
                  : idx % 4 === 2
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                  : 'bg-purple-950/30 border-purple-500/40 text-purple-300';

                return (
                  <div 
                    key={keyName} 
                    className={`p-4 rounded-2xl text-center border ${cardColor}`}
                  >
                    {sampleTrial?.stimulusType === 'spatial_grid' ? (
                      <div className="w-14 h-14 mx-auto mb-2 grid grid-cols-3 gap-1 p-1 bg-slate-900 rounded-lg border border-slate-700">
                        {[0, 1, 2].map(r => 
                          [0, 1, 2].map(c => {
                            const isCell = (sampleTrial.gridRow === r && sampleTrial.gridCol === c) || 
                                           (sampleTrial.stimulusValue.includes('top_left') && r === 0 && c === 0) ||
                                           (sampleTrial.stimulusValue.includes('center') && r === 1 && c === 1) ||
                                           (sampleTrial.stimulusValue.includes('top_right') && r === 0 && c === 2) ||
                                           (sampleTrial.stimulusValue.includes('bottom_right') && r === 2 && c === 2) ||
                                           (sampleTrial.stimulusValue.includes('bottom_left') && r === 2 && c === 0);
                            return (
                              <div
                                key={`${r}-${c}`}
                                className={`rounded-sm ${isCell ? 'bg-sky-400' : 'bg-slate-800'}`}
                              />
                            );
                          })
                        )}
                      </div>
                    ) : sampleTrial?.stimulusType === 'text' || sampleTrial?.stimulusType === 'word_ink' ? (
                      <div className="text-lg font-bold font-mono py-2 truncate" style={{ color: sampleTrial.hexColor || '#fff' }}>
                        {sampleTrial.stimulusText || sampleTrial.stimulusValue.toUpperCase()}
                      </div>
                    ) : sampleTrial?.stimulusType === 'color_square' ? (
                      <div 
                        className="w-12 h-12 rounded-lg mx-auto mb-2 shadow-lg"
                        style={{ backgroundColor: sampleTrial?.hexColor || '#ef4444' }}
                      />
                    ) : (
                      <div 
                        className="w-12 h-12 rounded-full mx-auto mb-2 shadow-lg"
                        style={{ backgroundColor: sampleTrial?.hexColor || (idx === 0 ? '#ef4444' : '#3b82f6') }}
                      />
                    )}
                    <div className="text-xs font-bold text-white uppercase mb-1 truncate">
                      {sampleTrial?.condition || `Condition ${idx + 1}`}
                    </div>
                    <div className="text-xs font-mono">
                      Press <kbd className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-white font-bold">{keyName.toUpperCase()}</kbd>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 text-xs text-slate-300 leading-relaxed whitespace-pre-line">
              {compiled.instructionContent}
            </div>

            <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Response Deadline: <strong className="text-slate-200">{compiled.responseDeadlineMs} ms</strong></span>
              <span>Total Trials: <strong className="text-slate-200">{trialQueue.length}</strong></span>
              <span>Theme: <strong className="text-purple-400">{compiled.gameSkinEnabled ? 'Space Arcade HUD' : 'Academic Plain'}</strong></span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                setPracticeIdx(0);
                setPracticeFeedback(null);
                setStage('PRACTICE');
              }}
              className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-all flex items-center justify-center gap-2"
            >
              <HelpCircle className="h-4 w-4" />
              <span>Practice (2 Trials)</span>
            </button>

            <button
              onClick={() => setStage('RUNNING')}
              className="py-3 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20"
            >
              <span>{compiled.continueButtonText} ({trialQueue.length} Trials)</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // STAGE 4: Interactive Practice Mode
  if (stage === 'PRACTICE') {
    const practiceTrial = trialQueue[practiceIdx % trialQueue.length] || trialQueue[0];
    const isPracticeFinished = practiceIdx >= 2;

    const handlePracticeKey = (key: string) => {
      if (isPracticeFinished) return;
      const isCorrect = key.toLowerCase() === practiceTrial.expectedKey.toLowerCase();
      if (isCorrect) {
        if (compiled.soundEnabled) soundEffects.playLaserHit();
        setPracticeFeedback(`✓ Correct! Key "${key.toUpperCase()}" registered.`);
      } else {
        if (compiled.soundEnabled) soundEffects.playDeflect();
        setPracticeFeedback(`✗ Incorrect. Expected "${practiceTrial.expectedKey.toUpperCase()}".`);
      }
      setTimeout(() => {
        setPracticeFeedback(null);
        setPracticeIdx(i => i + 1);
      }, 700);
    };

    return (
      <div className="max-w-xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/30 text-xs font-mono mb-4">
            Practice Sandbox ({Math.min(practiceIdx + 1, 2)} / 2)
          </div>

          {!isPracticeFinished ? (
            <div className="py-8">
              <p className="text-xs text-slate-400 mb-6">
                Test your response. Click a key button or press on your physical keyboard:
              </p>

              {/* Render Practice Stimulus */}
              <div className="flex items-center justify-center mb-6">
                {practiceTrial.stimulusType === 'text' || practiceTrial.stimulusType === 'word_ink' ? (
                  <div className="text-3xl font-black font-mono tracking-widest" style={{ color: practiceTrial.hexColor || '#fff' }}>
                    {practiceTrial.stimulusText || practiceTrial.stimulusValue.toUpperCase()}
                  </div>
                ) : (
                  <div 
                    style={{ backgroundColor: practiceTrial.hexColor || '#ef4444' }}
                    className="w-24 h-24 rounded-full shadow-lg"
                  />
                )}
              </div>

              {practiceFeedback && (
                <div className={`text-sm font-bold font-mono mb-4 ${practiceFeedback.startsWith('✓') ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {practiceFeedback}
                </div>
              )}

              <div className="flex justify-center gap-4">
                {compiled.allowedKeys.map((k) => (
                  <button
                    key={k}
                    onClick={() => handlePracticeKey(k)}
                    className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 font-mono font-bold text-white text-sm"
                  >
                    Press <span className="text-sky-400">{k.toUpperCase()}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="py-6">
              <CheckCircle className="h-12 w-12 text-emerald-400 mx-auto mb-3" />
              <h2 className="text-base font-bold text-white mb-2">Practice Complete!</h2>
              <p className="text-xs text-slate-400 mb-6">
                You understand the key mappings and timing. Ready to start the empirical block?
              </p>
              <button
                onClick={() => setStage('RUNNING')}
                className="w-full py-3 px-6 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm shadow-lg shadow-emerald-500/20"
              >
                Launch Main Experiment ({trialQueue.length} Trials)
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // STAGE 5: Debriefing Screen
  if (stage === 'DEBRIEF') {
    const trials = recordedTrialsRef.current;
    const correctCount = trials.filter(t => t.isCorrect).length;
    const accuracy = trials.length ? Math.round((correctCount / trials.length) * 100) : 0;
    const validRTs = trials.filter(t => t.reactionTimeMs !== null).map(t => t.reactionTimeMs!);
    const meanRT = validRTs.length ? Math.round(validRTs.reduce((a, b) => a + b, 0) / validRTs.length) : 0;

    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className="bg-[#0d1322] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto mb-4 text-emerald-400">
            <CheckCircle className="h-8 w-8" />
          </div>

          <h1 className="text-xl font-bold text-white mb-1">{compiled.debriefTitle}</h1>
          <p className="text-xs text-slate-400 mb-6">
            {compiled.debriefContent} All {trials.length} trials executed and committed to storage.
          </p>

          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="text-[10px] font-mono text-slate-400">Total Score</div>
              <div className="text-xl font-black font-mono text-yellow-300 mt-1">{score}</div>
            </div>
            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="text-[10px] font-mono text-slate-400">Accuracy</div>
              <div className="text-xl font-black font-mono text-emerald-400 mt-1">{accuracy}%</div>
            </div>
            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
              <div className="text-[10px] font-mono text-slate-400">Mean RT</div>
              <div className="text-xl font-black font-mono text-sky-400 mt-1">{meanRT} ms</div>
            </div>
          </div>

          {/* Anonymous Deletion Receipt */}
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 text-left text-xs text-slate-400 mb-6">
            <div className="font-semibold text-slate-300 mb-1">Anonymous Ethics Receipt Token</div>
            <div className="font-mono text-sky-400 bg-slate-950 p-2 rounded-lg select-all border border-slate-800 text-[11px]">
              {pseudonymToken}
            </div>
            <p className="text-[10px] text-slate-500 mt-2">
              Save this token. Under ethics protocols, you can provide this token to researchers at any time to request complete erasure of your trial microdata.
            </p>
          </div>

          <button
            onClick={onSessionComplete}
            className="w-full py-3 px-6 rounded-2xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-sm transition-all"
          >
            View Real-Time Data in Researcher Dashboard
          </button>
        </div>
      </div>
    );
  }

  // STAGE 6: LIVE RUNNING EXPERIMENT STAGE
  const currentItem = trialQueue[currentTrialIdx];

  return (
    <div className="relative w-full h-[calc(100vh-4rem)] flex items-center justify-center bg-[#070a13] overflow-hidden select-none">
      {/* Gamified Space HUD */}
      {compiled.gameSkinEnabled && (
        <SpaceArcadeHUD
          score={score}
          streak={streak}
          trialCurrent={currentTrialIdx + 1}
          trialTotal={trialQueue.length}
          feedbackText={hudFeedback?.text || null}
          feedbackColor={hudFeedback?.color || null}
        />
      )}

      {/* Starfield Glow */}
      {compiled.gameSkinEnabled && (
        <div className="absolute inset-0 bg-radial-glow pointer-events-none" />
      )}

      {/* Main Trial Stage Arena */}
      <div className="relative z-10 flex flex-col items-center justify-center">
        {/* Phase: Fixation Crosshair */}
        {trialPhase === 'fixation' && (
          <div className="flex items-center justify-center w-24 h-24">
            <div className="w-10 h-1 bg-slate-400 rounded-full absolute" />
            <div className="w-1 h-10 bg-slate-400 rounded-full absolute" />
          </div>
        )}

        {/* Phase: Stimulus (Circle, Square, Text, or Word Ink) */}
        {trialPhase === 'stimulus' && currentItem && (
          <div>
            {currentItem.stimulusType === 'spatial_grid' ? (
              <div className="grid grid-cols-3 gap-3 p-5 bg-slate-900/90 rounded-3xl border border-slate-700/80 shadow-2xl">
                {[0, 1, 2].map(r => 
                  [0, 1, 2].map(c => {
                    const isTarget = (
                      (currentItem.gridRow === r && currentItem.gridCol === c) ||
                      (currentItem.stimulusValue.includes('top_left') && r === 0 && c === 0) ||
                      (currentItem.stimulusValue.includes('top_right') && r === 0 && c === 2) ||
                      (currentItem.stimulusValue.includes('bottom_left') && r === 2 && c === 0) ||
                      (currentItem.stimulusValue.includes('bottom_right') && r === 2 && c === 2) ||
                      (currentItem.stimulusValue.includes('center') && r === 1 && c === 1) ||
                      (currentItem.stimulusValue === `grid_${r}_${c}`)
                    );
                    return (
                      <div
                        key={`${r}-${c}`}
                        style={{
                          backgroundColor: isTarget ? (currentItem.hexColor || '#38bdf8') : 'rgba(30, 41, 59, 0.7)',
                          boxShadow: isTarget && compiled.gameSkinEnabled ? `0 0 35px ${currentItem.hexColor || '#38bdf8'}` : 'none'
                        }}
                        className={`w-20 h-20 rounded-2xl transition-all border ${
                          isTarget ? 'border-white scale-105 ring-2 ring-white/50' : 'border-slate-800'
                        }`}
                      />
                    );
                  })
                )}
              </div>
            ) : currentItem.stimulusType === 'text' || currentItem.stimulusType === 'word_ink' ? (
              <div 
                style={{ 
                  color: currentItem.hexColor || '#ffffff',
                  textShadow: compiled.gameSkinEnabled ? `0 0 35px ${currentItem.hexColor}` : 'none'
                }}
                className="text-6xl font-black font-mono tracking-widest text-center"
              >
                {currentItem.stimulusText || currentItem.stimulusValue.toUpperCase()}
              </div>
            ) : currentItem.stimulusType === 'color_square' ? (
              <div 
                style={{ 
                  backgroundColor: currentItem.hexColor || '#ef4444',
                  boxShadow: compiled.gameSkinEnabled ? `0 0 45px ${currentItem.hexColor}` : 'none'
                }}
                className="w-32 h-32 rounded-xl transition-transform"
              />
            ) : (
              <div 
                style={{ 
                  backgroundColor: currentItem.hexColor || '#ef4444',
                  boxShadow: compiled.gameSkinEnabled ? `0 0 45px ${currentItem.hexColor}` : 'none'
                }}
                className="w-32 h-32 rounded-full transition-transform"
              />
            )}
          </div>
        )}

        {/* Phase: Blank ITI */}
        {trialPhase === 'iti' && (
          <div className="w-32 h-32" />
        )}
      </div>

      {/* Dynamic Keyboard Controls Reminder at Bottom */}
      <div className="absolute bottom-6 inset-x-0 flex justify-center pointer-events-none">
        <div className="bg-slate-950/70 backdrop-blur-md px-4 py-2 rounded-xl border border-slate-800/80 text-[11px] font-mono text-slate-400 flex items-center gap-3">
          {compiled.allowedKeys.map((k, idx) => (
            <React.Fragment key={k}>
              {idx > 0 && <span className="text-slate-600">|</span>}
              <span>
                <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-sky-400 font-bold mr-1">
                  {k.toUpperCase()}
                </kbd>
                = {trialQueue.find(t => t.expectedKey.toLowerCase() === k.toLowerCase())?.condition || `Condition ${idx + 1}`}
              </span>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};
