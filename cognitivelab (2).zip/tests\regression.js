import { Mulberry32, FactorialEngine } from '../src/dsl/randomization.ts';
import { ExperimentValidator } from '../src/dsl/validator.ts';
import { ExperimentCompiler } from '../src/runtime/compiler.ts';
import { Exporter } from '../src/export/Exporter.ts';
import { defaultExperimentDSL } from '../src/dsl/defaultExperiment.ts';
import { SemanticParser } from '../src/dsl/semanticParser.ts';
import { StatisticalEngine } from '../src/analytics/statisticalEngine.ts';
import { QualityEngine } from '../src/analytics/qualityEngine.ts';

console.log("=== RUNNING COGNITIVELAB REGRESSION TEST SUITE ===");

let passed = 0;
let failed = 0;

function assert(condition, testName) {
  if (condition) {
    console.log(`✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`✗ FAIL: ${testName}`);
    failed++;
  }
}

// 1. Test PRNG Determinism
const prng1 = new Mulberry32(12345);
const prng2 = new Mulberry32(12345);
const val1 = prng1.next();
const val2 = prng2.next();
assert(val1 === val2, "Mulberry32 produces identical output from identical seed");

// 2. Test FactorialEngine Multi-Factor Combinations & Balance
const testFactors = [
  {
    name: "word",
    levels: [
      { value: "red", metadata: { text: "RED" } },
      { value: "blue", metadata: { text: "BLUE" } }
    ]
  },
  {
    name: "ink",
    levels: [
      { value: "red", metadata: { hex: "#ef4444", expected_key: "r" } },
      { value: "blue", metadata: { hex: "#3b82f6", expected_key: "b" } }
    ]
  }
];

const trialBlock = FactorialEngine.generateBalancedBlock(
  { factors: testFactors, total_trials: 32, max_consecutive_identical: 2 },
  new Mulberry32(42)
);

assert(trialBlock.length === 32, `Generated expected 32 trials (got ${trialBlock.length})`);

// Check equal distribution across all 4 Cartesian cells (2 words x 2 inks = 4 cells, 8 per cell)
const cellCounts = {};
trialBlock.forEach(t => {
  cellCounts[t.condition] = (cellCounts[t.condition] || 0) + 1;
});
const counts = Object.values(cellCounts);
assert(counts.length === 4 && counts.every(c => c === 8), `Exact factorial balance achieved across 4 cells: ${JSON.stringify(cellCounts)}`);

// 3. Test Two-Tier Validator on Canonical DSL
const validResult = ExperimentValidator.validate(defaultExperimentDSL);
assert(validResult.isValid === true, "Canonical defaultExperimentDSL passes validation");

// Test Validator Catching Broken Topologies
const brokenDSL = JSON.parse(JSON.stringify(defaultExperimentDSL));
// Disconnect end node
brokenDSL.edges = brokenDSL.edges.filter(e => e.to !== 'node_end');
const brokenResult = ExperimentValidator.validate(brokenDSL);
assert(brokenResult.isValid === false, "Validator catches unreachable node_end");
assert(brokenResult.issues.some(i => i.id === 'ERR_END_UNREACHABLE'), "Identified ERR_END_UNREACHABLE error ID");

// 4. Test Runtime Compiler
const compiled = ExperimentCompiler.compile(defaultExperimentDSL, 9999);
assert(compiled.allowedKeys.includes('a') && compiled.allowedKeys.includes('l'), "Compiler extracts allowed response keys");
assert(compiled.trials.length === 30, "Compiler generates exact trial queue length");
assert(compiled.responseDeadlineMs === 1500, "Compiler extracts response deadline");

// 5. Test Dynamic Exporter
const mockTrials = [
  {
    id: "t1",
    sessionId: "sess_test_1",
    trialIndex: 1,
    nodeId: "stimulus",
    condition: "congruent_red",
    stimulus: "RED",
    responseKey: "r",
    expectedKey: "r",
    isCorrect: true,
    reactionTimeMs: 312.45,
    frameOnsetTs: 1000.5,
    displayLagMs: 0.8,
    score: 100,
    streak: 1,
    qualityFlags: [],
    timestamp: new Date().toISOString()
  },
  {
    id: "t2",
    sessionId: "sess_test_1",
    trialIndex: 2,
    nodeId: "stimulus",
    condition: "incongruent_blue",
    stimulus: "RED",
    responseKey: "b",
    expectedKey: "b",
    isCorrect: true,
    reactionTimeMs: 388.10,
    frameOnsetTs: 2000.5,
    displayLagMs: 0.9,
    score: 200,
    streak: 2,
    qualityFlags: [],
    timestamp: new Date().toISOString()
  }
];

const longCSV = Exporter.generateLongCSV(mockTrials, defaultExperimentDSL);
assert(longCSV.includes("congruent_red") && longCSV.includes("incongruent_blue"), "Long CSV formats custom conditions");

const wideCSV = Exporter.generateWideCSV(mockTrials, defaultExperimentDSL);
assert(wideCSV.includes("mean_rt_congruent_red") && wideCSV.includes("mean_rt_incongruent_blue"), "Wide CSV dynamically generates condition-specific RT and accuracy columns");

// 6. Test SemanticParser Natural Language → DSL Synthesis
const foodPrompt = "Create a game to see which food boys like. Display food items (Pizza, Burger, Salad, Ice Cream). Press A for Fast Food and L for Sweets/Salad. 32 balanced trials with points.";
const foodResult = SemanticParser.parseLocally(foodPrompt);
assert(foodResult.dsl.experiment.id.includes('food'), "SemanticParser recognizes Food Preference paradigm");
const foodValidation = ExperimentValidator.validate(foodResult.dsl);
assert(foodValidation.isValid === true, "Food preference synthesized DSL passes all validation rules");

const asteroidPrompt = "Design a 3-choice deep space asteroid defense game. Show red, blue, or green cosmic crystals. Press J for red, K for blue, and L for green. 36 balanced trials.";
const asteroidResult = SemanticParser.parseLocally(asteroidPrompt);
assert(asteroidResult.intent.allowedKeys.length === 3, "SemanticParser recognizes 3AFC paradigm with J, K, L keys");
const asteroidValidation = ExperimentValidator.validate(asteroidResult.dsl);
assert(asteroidValidation.isValid === true, "3AFC asteroid synthesized DSL passes all validation rules");

// 7. Test Conversational Iterative Patching (RFC 6902-style edits)
const patch1 = SemanticParser.applyIterativePatch(asteroidResult.dsl, "Change trials to 48");
const randNode = patch1.updatedDsl.nodes.find(n => n.type === 'randomization_balanced_block');
assert(randNode?.config.total_trials === 48, "Iterative patch accurately modified total trial count to 48");

const patch2 = SemanticParser.applyIterativePatch(asteroidResult.dsl, "Use arrow keys");
const respNode = patch2.updatedDsl.nodes.find(n => n.type === 'response_keyboard');
assert(respNode?.config.allowed_keys.includes('arrowleft'), "Iterative patch dynamically remapped keys to arrows");

const patch3 = SemanticParser.applyIterativePatch(asteroidResult.dsl, "Switch to academic plain skin");
assert(patch3.updatedDsl.game_skin.enabled === false, "Iterative patch toggled skin to academic plain");

// 8. Test StatisticalEngine Deterministic Math Kernel
const testDataA = [320, 340, 310, 350, 330, 315, 345, 325];
const testDataB = [420, 440, 410, 460, 430, 415, 450, 435];

const descA = StatisticalEngine.computeDescriptives(testDataA);
assert(descA.mean === 329.375, `StatisticalEngine computes exact mean (got ${descA.mean})`);
assert(descA.median === 327.5, `StatisticalEngine computes exact median (got ${descA.median})`);

const tResult = StatisticalEngine.welchTTest(testDataA, testDataB);
assert(tResult.isSignificant === true, `Welch's t-test detects significant difference (p=${tResult.pValue})`);
assert(tResult.delta === 103.1, `Welch's t-test computes correct mean difference (got ${tResult.delta})`);

const cohenResult = StatisticalEngine.cohensD(testDataA, testDataB);
assert(cohenResult.interpretation === 'large', `Cohen's d identifies large effect size (d=${cohenResult.d})`);

const outlierSet = [300, 305, 310, 315, 320, 950];
const trimmed = StatisticalEngine.tukeyTrim(outlierSet);
assert(trimmed.outliers.includes(950) && trimmed.clean.length === 5, "Tukey 1.5x IQR outlier trimmer isolates extreme latency 950ms");

// 9. Test Smart QualityEngine Heuristics & Non-Destructive Filtering
const fastTrial = {
  id: "ft_1",
  sessionId: "s_1",
  trialIndex: 1,
  nodeId: "stim",
  condition: "c",
  stimulus: "S",
  responseKey: "a",
  expectedKey: "a",
  isCorrect: true,
  reactionTimeMs: 120, // Fast guess <150ms
  frameOnsetTs: 100,
  displayLagMs: 0.5,
  score: 100,
  streak: 1,
  qualityFlags: [],
  timestamp: new Date().toISOString()
};

const flags = QualityEngine.diagnoseTrial(fastTrial);
assert(flags.includes('fast_guess'), "QualityEngine flags anticipatory reaction <150ms as fast_guess");

const perseverationCohort = [
  { id: "p1", sessionId: "s1", responseKey: "a" },
  { id: "p2", sessionId: "s1", responseKey: "a" },
  { id: "p3", sessionId: "s1", responseKey: "a" },
  { id: "p4", sessionId: "s1", responseKey: "a" },
  { id: "p5", sessionId: "s1", responseKey: "a" },
  { id: "p6", sessionId: "s1", responseKey: "a" }
];
const perseverationFlags = QualityEngine.detectPerseveration(perseverationCohort);
assert(perseverationFlags.size === 6, "QualityEngine detects motor perseveration keypress streak >= 6");

// 10. Test Dynamic Semantic Parser for Spatial Grid Working Memory
const spatialPrompt = "Design a spatial grid working memory experiment with 3x3 matrix. Participant responds with Z for left side and M for right side. 32 balanced trials.";
const spatialResult = SemanticParser.parseLocally(spatialPrompt);
assert(spatialResult.intent.paradigm === 'spatial_grid_working_memory', "SemanticParser dynamically synthesizes Spatial Grid Working Memory paradigm");
assert(spatialResult.intent.factors[0].levels.some(l => l.metadata.type === 'spatial_grid'), "Spatial factor levels contain type 'spatial_grid'");
assert(spatialResult.intent.allowedKeys.includes('z') && spatialResult.intent.allowedKeys.includes('m'), "Spatial factor levels mapped to extracted Z/M keys");
const spatialValidation = ExperimentValidator.validate(spatialResult.dsl);
assert(spatialValidation.isValid === true, "Spatial grid synthesized DSL passes all validation rules");

// 11. Test Dynamic Semantic Parser for Go/No-Go Inhibitory Control
const goNogoPrompt = "Create a Go/No-Go inhibitory control test. Show green circle for Go (press spacebar) and red circle for No-Go (withhold response). 32 trials.";
const goNogoResult = SemanticParser.parseLocally(goNogoPrompt);
assert(goNogoResult.intent.paradigm === 'go_nogo_inhibitory_control', "SemanticParser dynamically synthesizes Go/No-Go paradigm");
assert(goNogoResult.intent.allowedKeys.includes('space'), "Go/No-Go allowed keys include 'space'");
assert(goNogoResult.intent.factors[0].levels.some(l => l.metadata.expected_key === 'none'), "Go/No-Go includes withhold condition with expected_key 'none'");
const goNogoValidation = ExperimentValidator.validate(goNogoResult.dsl);
assert(goNogoValidation.isValid === true, "Go/No-Go synthesized DSL passes all validation rules");

// 12. Test Dynamic Semantic Parser for Arbitrary Categories (e.g. Fruits vs Vehicles)
const categoryPrompt = "Create an experiment showing fruits vs vehicles. Show Apple, Orange, Car, Truck. Press F for fruits and V for vehicles. 32 trials.";
const categoryResult = SemanticParser.parseLocally(categoryPrompt);
assert(categoryResult.intent.paradigm.includes('category') || categoryResult.intent.paradigm.includes('discrimination'), "SemanticParser dynamically handles arbitrary category prompt");
assert(categoryResult.intent.factors[0].levels.some(l => l.metadata.type === 'text'), "Category factors use stimulus_type 'text'");
assert(categoryResult.intent.allowedKeys.includes('f') && categoryResult.intent.allowedKeys.includes('v'), "Category factor levels mapped to extracted F and V keys");
const categoryValidation = ExperimentValidator.validate(categoryResult.dsl);
assert(categoryValidation.isValid === true, "Category synthesized DSL passes all validation rules");

// 13. Test Compact Viewport Node Layout in Synthesized DSL
const maxNodeX = Math.max(...categoryResult.dsl.nodes.map(n => n.position?.x ?? 0));
assert(maxNodeX <= 1500, `Synthesized nodes laid out in compact on-screen pipeline (max x=${maxNodeX}px <= 1500px)`);

// 14. Test Canonical Experiment Store
import { canonicalExperiments, ExperimentStore } from '../src/runtime/experimentStore.ts';
assert(canonicalExperiments.length >= 5, `Curated experiment registry contains ${canonicalExperiments.length} canonical protocols`);
const spatialExp = ExperimentStore.getExperiment('exp_spatial_grid_001');
assert(spatialExp.experiment.title.includes('Spatial Grid'), "ExperimentStore retrieves canonical Spatial Grid protocol");
const stroopExp = ExperimentStore.getExperiment('exp_stroop_canonical');
assert(stroopExp.experiment.title.includes('Stroop'), "ExperimentStore retrieves canonical Stroop protocol");

// 15. Test Dynamic "Press F for Car and D for Cake" with Emojis
const carCakePrompt = "Press F for Car and D for Cake";
const carCakeResult = SemanticParser.parseLocally(carCakePrompt);
assert(carCakeResult.dsl.experiment.title.includes("Car vs Cake"), "Car vs Cake generates custom title");
assert(carCakeResult.intent.allowedKeys.includes('f') && carCakeResult.intent.allowedKeys.includes('d'), "Car vs Cake maps F and D keys");
assert(carCakeResult.intent.factors[0].levels[0].metadata.text.includes('🚗'), "Car stimulus includes car emoji 🚗");
assert(carCakeResult.intent.factors[0].levels[1].metadata.text.includes('🍰'), "Cake stimulus includes cake emoji 🍰");
const carCakeValidation = ExperimentValidator.validate(carCakeResult.dsl);
assert(carCakeValidation.isValid === true, "Car vs Cake synthesized DSL passes all validation rules");

console.log(`\n=== RESULTS: ${passed} PASSED, ${failed} FAILED ===\n`);
if (failed > 0) process.exit(1);
