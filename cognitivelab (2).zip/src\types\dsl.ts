export type NodeType =
  | 'flow_start'
  | 'flow_end'
  | 'presentation_text'
  | 'presentation_fixation'
  | 'presentation_stimulus'
  | 'response_keyboard'
  | 'logic_condition'
  | 'logic_loop'
  | 'randomization_balanced_block'
  | 'game_reward'
  | 'timing_wait'
  | 'timing_calibration'
  | 'data_record_trial';

export interface DSLNode {
  id: string;
  type: NodeType;
  label: string;
  config: Record<string, any>;
  position?: { x: number; y: number };
}

export interface DSLEdge {
  id: string;
  from: string;
  to: string;
  port?: string;
  label?: string;
}

export interface ExperimentMetadata {
  id: string;
  slug: string;
  version: number;
  title: string;
  description: string;
  created_at: string;
  author: {
    user_id: string;
    institution: string;
  };
  reproducibility: {
    dsl_version: string;
    target_runtime: string;
    hash_sha256?: string;
  };
}

export interface ParticipantSettings {
  allow_anonymous: boolean;
  enforce_fullscreen: boolean;
  minimum_display_hz: number;
  device_allowlist: string[];
  required_inputs: string[];
}

export interface ConsentSettings {
  required: boolean;
  ethics_protocol_id: string;
  statement_text: string;
  require_checkbox: boolean;
  minimum_age: number;
}

export interface GameSkinSettings {
  enabled: boolean;
  theme: 'deep-space-arcade' | 'academic-clean' | 'retro-synth';
  sound_enabled: boolean;
  hud_elements: {
    show_score: boolean;
    show_streak: boolean;
    show_progress_bar: boolean;
  };
  score_rules: {
    correct_base_points: number;
    streak_bonus_multiplier: number;
    incorrect_penalty: number;
    max_rt_for_bonus_ms: number;
  };
}

export interface ExperimentDSL {
  $schema?: string;
  experiment: ExperimentMetadata;
  participant_settings: ParticipantSettings;
  consent_settings: ConsentSettings;
  variables: Record<string, { type: 'string' | 'number' | 'boolean'; default: any; scope: 'global' | 'trial' }>;
  game_skin: GameSkinSettings;
  nodes: DSLNode[];
  edges: DSLEdge[];
}

export interface ValidationIssue {
  id: string;
  severity: 'critical' | 'warning' | 'info';
  category: 'structural' | 'logical' | 'timing' | 'ethics';
  nodeId?: string;
  message: string;
  suggestion?: string;
}

export interface TrialRecord {
  id: string;
  sessionId: string;
  experimentId?: string;
  experimentVersion?: number;
  trialIndex: number;
  nodeId: string;
  condition: string;
  stimulus: string;
  responseKey: string | null;
  expectedKey: string;
  isCorrect: boolean | null;
  reactionTimeMs: number | null;
  frameOnsetTs: number;
  displayLagMs: number;
  score: number;
  streak: number;
  qualityFlags: string[];
  timestamp: string;
}

export interface SessionCalibration {
  sessionId: string;
  measuredRefreshHz: number;
  frameJitterStdMs: number;
  userAgent: string;
  viewportDimensions: string;
  isStable: boolean;
}
