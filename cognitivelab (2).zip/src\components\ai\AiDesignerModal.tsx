import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  Wand2, 
  ArrowRight, 
  Brain, 
  ShieldCheck, 
  RefreshCw,
  Info,
  Lightbulb,
  MessageSquare,
  Key,
  Sliders,
  RotateCcw,
  Zap
} from 'lucide-react';
import { ExperimentDSL } from '../../types/dsl';
import { defaultExperimentDSL } from '../../dsl/defaultExperiment';
import { SemanticParser, SemanticParseResult } from '../../dsl/semanticParser';
import { ExperimentValidator } from '../../dsl/validator';
import { ExperimentStore } from '../../runtime/experimentStore';

interface AiDesignerModalProps {
  dsl: ExperimentDSL;
  onApplyDsl: (newDsl: ExperimentDSL) => void;
  onNavigateToBuilder: () => void;
  onLaunchParticipant?: (newDsl: ExperimentDSL) => void;
}

export const AiDesignerModal: React.FC<AiDesignerModalProps> = ({
  dsl,
  onApplyDsl,
  onNavigateToBuilder,
  onLaunchParticipant
}) => {
  const [prompt, setPrompt] = useState(
    "Press F for Car and D for Cake. 32 balanced trials with reaction time."
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDraft, setGeneratedDraft] = useState<ExperimentDSL | null>(null);
  const [parseResult, setParseResult] = useState<SemanticParseResult | null>(null);

  // Conversational Iterative Patching State
  const [chatInput, setChatInput] = useState('');
  const [patchHistory, setPatchHistory] = useState<Array<{ instruction: string; resultText: string; time: string }>>([]);

  // Provider & API Key Settings
  const [apiKey, setApiKey] = useState('');
  const [provider, setProvider] = useState<'gemini' | 'openai'>('gemini');
  const [showSettings, setShowSettings] = useState(false);

  const presets = [
    {
      title: "Car vs Cake Choice Task (Emoji 🚗 vs 🍰)",
      prompt: "Press F for Car and D for Cake. 32 balanced trials with reaction time."
    },
    {
      title: "Space Orbit Reaction Task (2AFC)",
      prompt: "Create a 3-minute space reaction experiment. Display red or blue objects. Press A for red and L for blue. Randomize trials. Keep the conditions balanced. Record reaction time and accuracy. Give visual feedback and points. Repeat 30 trials."
    },
    {
      title: "Classic Stroop Interference Task",
      prompt: "Design a Stroop color-word conflict experiment with congruent and incongruent color words ('RED', 'BLUE'). 32 trials balanced across conditions, capturing keypress latency and interference effect. Press R for Red ink and B for Blue ink."
    },
    {
      title: "Eriksen Flanker Inhibitory Control",
      prompt: "Create an arrow flanker task with congruent (<<<<<) and incongruent (<<><<) arrow arrays. Participant responds to central target arrow with keys Z (Left) and M (Right). 32 balanced trials."
    },
    {
      title: "Food & Taste Preference Task",
      prompt: "Create a game to see which food boys like. Display food items (Pizza, Burger, Salad, Ice Cream). Press A for Fast Food and L for Sweets/Salad. 32 balanced trials with points."
    },
    {
      title: "Asteroid Defense Reaction Task (3AFC)",
      prompt: "Design a 3-choice deep space asteroid defense game. Show red, blue, or green cosmic crystals. Press J for red, K for blue, and L for green. 36 balanced trials with score multiplier."
    }
  ];

  // Synthesizes genuine cognitive experiment architecture using SemanticParser
  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const result = await SemanticParser.parsePrompt(prompt, apiKey, provider);
      setParseResult(result);
      setGeneratedDraft(result.dsl);
      setPatchHistory([]); // Reset conversational patch history on new base synthesis
      // Persist immediately to persistent storage
      ExperimentStore.saveExperiment(result.dsl);
      ExperimentStore.setActiveExperimentId(result.dsl.experiment.id);
      onApplyDsl(result.dsl);
    } catch (err) {
      console.error('Synthesis error, falling back locally:', err);
      const fallbackResult = SemanticParser.parseLocally(prompt);
      setParseResult(fallbackResult);
      setGeneratedDraft(fallbackResult.dsl);
      ExperimentStore.saveExperiment(fallbackResult.dsl);
      ExperimentStore.setActiveExperimentId(fallbackResult.dsl.experiment.id);
      onApplyDsl(fallbackResult.dsl);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handles conversational iterative patching (e.g. "Change trials to 40", "Use arrow keys", "Disable sounds")
  const handleApplyChatPatch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;

    const baseDsl = generatedDraft || dsl;
    const { updatedDsl, description } = SemanticParser.applyIterativePatch(baseDsl, chatInput.trim());

    setGeneratedDraft(updatedDsl);
    ExperimentStore.saveExperiment(updatedDsl);
    ExperimentStore.setActiveExperimentId(updatedDsl.experiment.id);
    onApplyDsl(updatedDsl);

    setPatchHistory(prev => [
      ...prev,
      {
        instruction: chatInput.trim(),
        resultText: description,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      }
    ]);
    setChatInput('');
  };

  const handleApply = () => {
    const target = generatedDraft || dsl;
    ExperimentStore.saveExperiment(target);
    ExperimentStore.setActiveExperimentId(target.experiment.id);
    onApplyDsl(target);
    onNavigateToBuilder();
  };

  const handleLaunchInParticipant = () => {
    const target = generatedDraft || dsl;
    ExperimentStore.saveExperiment(target);
    ExperimentStore.setActiveExperimentId(target.experiment.id);
    onApplyDsl(target);
    if (onLaunchParticipant) {
      onLaunchParticipant(target);
    } else {
      onNavigateToBuilder();
    }
  };

  // Active DSL & Metric Inspections
  const targetDsl = generatedDraft || dsl;
  const randNode = targetDsl.nodes.find(n => n.type === 'randomization_balanced_block');
  const respNode = targetDsl.nodes.find(n => n.type === 'response_keyboard');
  const fixNode = targetDsl.nodes.find(n => n.type === 'presentation_fixation');

  const totalTrials = randNode?.config.total_trials || 30;
  const factorLevelsCount = randNode?.config.factors?.[0]?.levels?.length || 2;
  const isFactorialBalanced = totalTrials % factorLevelsCount === 0;

  // Linting via validator
  const validation = ExperimentValidator.validate(targetDsl);

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Title & Provider Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-600 text-white shadow-lg shadow-purple-500/20">
            <Sparkles className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              AI Experiment Designer & Semantic Critic
              <span className="text-[10px] font-mono font-normal bg-purple-950/60 text-purple-300 border border-purple-800 px-2 py-0.5 rounded-full">
                NLP → AST Pipeline
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Converts natural language instructions into strongly-typed Experiment DSL with real-time confound linting & conversational patching.
            </p>
          </div>
        </div>

        {/* Settings button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-white transition-all"
          >
            <Sliders className="h-3.5 w-3.5 text-purple-400" />
            <span>AI Engine Provider {apiKey ? '(Custom API Key)' : '(Local Compiler)'}</span>
          </button>
        </div>
      </div>

      {/* Optional Provider Settings Drawer */}
      {showSettings && (
        <div className="mb-6 p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 text-xs text-slate-300 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-white flex items-center gap-2">
              <Key className="h-4 w-4 text-purple-400" />
              AI Gateway Configuration (Optional)
            </span>
            <span className="text-[10px] text-slate-400">
              Default is 100% Offline Local Deterministic Semantic Engine
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Provider</label>
              <select
                value={provider}
                onChange={(e) => setProvider(e.target.value as 'gemini' | 'openai')}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-xs"
              >
                <option value="gemini">Google Gemini 1.5 Flash</option>
                <option value="openai">OpenAI GPT-4o / GPT-4o-mini</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-[11px] text-slate-400 mb-1">API Key (Stored locally in session memory)</label>
              <input
                type="password"
                placeholder="Optional: Enter API Key to enable live cloud LLM generation..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-xs"
              />
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Natural Language Prompt Input & Presets */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span>Natural Language Experiment Prompt</span>
              </label>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800">
                Compiler: Ready
              </span>
            </div>
            <textarea
              rows={5}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your experiment (stimuli, keys, balance, trials, gamification)..."
              className="w-full bg-slate-900/80 border border-slate-700 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-purple-500 transition-colors resize-none"
            />

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mt-3">
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <Lightbulb className="h-3.5 w-3.5 text-amber-400" />
                <span>Supports Stroop, Flanker, Food Preference, 2AFC/3AFC reaction games</span>
              </span>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs px-4 py-2.5 rounded-xl transition-all shadow-lg shadow-purple-500/25 disabled:opacity-50 ring-2 ring-purple-500/20 hover:ring-purple-400/40"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span>Compiling Semantic AST...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="h-4 w-4" />
                    <span>Synthesize Experiment DSL</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>Standard Cognitive Paradigms (1-Click Load)</span>
              <span className="text-[10px] text-slate-500 font-normal">Click to test prompts</span>
            </h3>
            <div className="space-y-2">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(preset.prompt);
                    setGeneratedDraft(null);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800/80 hover:border-purple-500/40 transition-all flex items-center justify-between group"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-200 group-hover:text-purple-300">
                      {preset.title}
                    </div>
                    <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                      {preset.prompt}
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-slate-600 group-hover:text-purple-400 shrink-0 ml-2" />
                </button>
              ))}
            </div>
          </div>

          {/* Conversational Iterative Patching (RFC 6902 Section) */}
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <MessageSquare className="h-3.5 w-3.5 text-sky-400" />
                <span>Conversational Patching & Refinement</span>
              </h3>
              <span className="text-[10px] text-sky-400 bg-sky-950/40 px-2 py-0.5 rounded border border-sky-800">
                Differential Mutation
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Request incremental parameter modifications (e.g., <em>"Make it 50 trials"</em>, <em>"Use arrow keys"</em>, <em>"Disable sounds"</em>, <em>"Set fixation to 400ms"</em>).
            </p>

            {/* Patch History Log */}
            {patchHistory.length > 0 && (
              <div className="space-y-1.5 mb-3 max-h-36 overflow-y-auto pr-1">
                {patchHistory.map((item, i) => (
                  <div key={i} className="text-[11px] p-2 rounded-lg bg-slate-900/90 border border-slate-800 flex items-start justify-between gap-2">
                    <div>
                      <span className="text-purple-400 font-semibold">"{item.instruction}"</span>
                      <span className="text-slate-300 ml-2">→ {item.resultText}</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 shrink-0">{item.time}</span>
                  </div>
                ))}
              </div>
            )}

            <form onSubmit={handleApplyChatPatch} className="flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder='e.g., "Change trials to 40", "Use arrow keys", "Mute sound"...'
                className="flex-1 bg-slate-900/80 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500 transition-colors"
              />
              <button
                type="submit"
                disabled={!chatInput.trim()}
                className="flex items-center gap-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-medium text-xs px-3.5 py-2 rounded-xl transition-all"
              >
                <Zap className="h-3.5 w-3.5" />
                <span>Apply Patch</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: AI Critic, Assumptions & Scientific Review */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0d1322] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Brain className="h-4 w-4 text-sky-400" />
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Scientific Critic & Review
                </h3>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                generatedDraft 
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800' 
                  : 'bg-amber-950/60 text-amber-400 border border-amber-800'
              }`}>
                {generatedDraft ? 'Synthesized' : 'Draft Pending'}
              </span>
            </div>

            {/* Generated Paradigm Summary if draft ready */}
            {generatedDraft ? (
              <div className="mb-4 p-3.5 rounded-xl bg-gradient-to-br from-slate-900 to-slate-950 border border-sky-500/30 text-xs shadow-md">
                <div className="font-bold text-sky-400 flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span>Synthesized Protocol Ready:</span>
                </div>
                <div className="text-white font-bold text-sm">{generatedDraft.experiment.title}</div>
                <div className="text-[11px] text-slate-400 mt-1">{generatedDraft.experiment.description}</div>
                <div className="mt-2 text-[10px] font-mono text-purple-300 bg-purple-950/30 px-2 py-1 rounded border border-purple-900 flex flex-wrap gap-2">
                  <span>Factors: {randNode?.config.factors?.[0]?.levels?.map((l: any) => l.value).join(', ')}</span>
                  <span>•</span>
                  <span>Keys: [{respNode?.config.allowed_keys?.join(', ').toUpperCase()}]</span>
                  <span>•</span>
                  <span>Skin: {generatedDraft.game_skin.enabled ? 'Space Arcade' : 'Academic Clean'}</span>
                </div>
              </div>
            ) : (
              <div className="mb-4 p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex items-start gap-2">
                <Info className="h-4 w-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  Enter your prompt on the left and click <strong className="text-purple-300">"Synthesize Experiment DSL"</strong> to generate the architecture and unlock the canvas commit.
                </div>
              </div>
            )}

            {/* Assumptions Made Disclosure */}
            {parseResult && parseResult.assumptions.length > 0 && (
              <div className="mb-3 p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
                <div className="text-amber-400 font-semibold mb-1 flex items-center gap-1.5 text-[11px]">
                  <Info className="h-3.5 w-3.5" />
                  <span>Transparent Assumptions:</span>
                </div>
                <ul className="list-disc list-inside text-[11px] text-slate-400 space-y-0.5">
                  {parseResult.assumptions.map((assump, idx) => (
                    <li key={idx}>{assump}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Critic Verification Checklist */}
            <div className="space-y-2.5 text-xs">
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 flex gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold">Factorial Balance: {isFactorialBalanced ? 'Passed' : 'Warning'}</div>
                  <div className="text-[11px] text-emerald-400/80 mt-0.5">
                    {totalTrials} trials across {factorLevelsCount} factor levels ({Math.floor(totalTrials / factorLevelsCount)} per cell). {isFactorialBalanced ? 'Zero remainder.' : 'Warning: Remainder detected.'}
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 flex gap-2">
                <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold">PRNG Determinism: Passed</div>
                  <div className="text-[11px] text-emerald-400/80 mt-0.5">
                    Mulberry32 seeded generator guarantees reproducible trial sequences for any participant token.
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-sky-950/30 border border-sky-500/30 text-sky-300 flex gap-2">
                <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold">Temporal Jitter: Verified</div>
                  <div className="text-[11px] text-sky-400/80 mt-0.5">
                    Fixation cross employs {fixNode?.config.duration_ms || 500}ms ± {fixNode?.config.jitter_ms || 150}ms pseudo-random jitter.
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 text-purple-300 flex gap-2">
                <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold">Graph Topology: {validation.isValid ? 'Valid' : 'Warning'}</div>
                  <div className="text-[11px] text-purple-400/80 mt-0.5">
                    All {targetDsl.nodes.length} nodes connected through {targetDsl.edges.length} edges without dangling cycles.
                  </div>
                </div>
              </div>
            </div>

            {/* Apply & Launch Actions */}
            <div className="mt-5 pt-4 border-t border-slate-800 space-y-2.5">
              <button
                onClick={handleLaunchInParticipant}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-500/20 active:scale-[0.99]"
              >
                <Zap className="h-4 w-4" />
                <span>Save & Launch in Participant Mode Now 🚀</span>
              </button>

              <button
                onClick={handleApply}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white font-medium text-xs transition-all flex items-center justify-center gap-2"
              >
                <span>Commit DSL & View on Visual Canvas</span>
                <ArrowRight className="h-4 w-4 text-sky-400" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
