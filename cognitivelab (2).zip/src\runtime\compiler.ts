import { ExperimentDSL, DSLNode } from '../types/dsl';
import { FactorialEngine, BalancedTrialItem, Mulberry32 } from '../dsl/randomization';

export interface CompiledExperiment {
  title: string;
  ethicsProtocolId: string;
  consentStatement: string;
  requireCheckbox: boolean;
  minAge: number;
  instructionTitle: string;
  instructionContent: string;
  continueButtonText: string;
  allowedKeys: string[];
  responseDeadlineMs: number;
  fixationDurationMs: number;
  fixationJitterMs: number;
  itiDurationMs: number;
  trials: BalancedTrialItem[];
  gameSkinEnabled: boolean;
  soundEnabled: boolean;
  scoreRules: {
    basePoints: number;
    streakMultiplier: number;
  };
  debriefTitle: string;
  debriefContent: string;
}

export class ExperimentCompiler {
  public static compile(dsl: ExperimentDSL, sessionSeed: number): CompiledExperiment {
    const nodeMap = new Map<string, DSLNode>(dsl.nodes.map(n => [n.id, n]));

    // Find key nodes by type
    const consentNode = dsl.nodes.find(n => n.type === 'presentation_text' && (n.id.includes('consent') || n.label.toLowerCase().includes('consent')));
    const instructionNode = dsl.nodes.find(n => n.type === 'presentation_text' && (n.id.includes('instruction') || n.label.toLowerCase().includes('instruction') || n.label.toLowerCase().includes('briefing')));
    const debriefNode = dsl.nodes.find(n => n.type === 'presentation_text' && (n.id.includes('debrief') || n.label.toLowerCase().includes('debrief') || n.label.toLowerCase().includes('accomplished')));

    const randomizationNode = dsl.nodes.find(n => n.type === 'randomization_balanced_block');
    const fixationNode = dsl.nodes.find(n => n.type === 'presentation_fixation');
    const responseNode = dsl.nodes.find(n => n.type === 'response_keyboard');
    const rewardNode = dsl.nodes.find(n => n.type === 'game_reward' && (n.id.includes('correct') || (n.config.points && n.config.points > 0)));
    const itiNode = dsl.nodes.find(n => n.type === 'timing_wait');

    // Extract allowed keys
    const allowedKeys: string[] = responseNode?.config.allowed_keys 
      ? responseNode.config.allowed_keys.map((k: string) => String(k).toLowerCase()) 
      : ['a', 'l'];

    // Generate balanced trials
    const prng = new Mulberry32(sessionSeed);
    const trials = FactorialEngine.generateBalancedBlock(
      randomizationNode ? randomizationNode.config : {},
      prng
    );

    return {
      title: dsl.experiment.title || 'Cognitive Experiment',
      ethicsProtocolId: dsl.consent_settings.ethics_protocol_id || 'IRB-UNSPECIFIED',
      consentStatement: dsl.consent_settings.statement_text || (consentNode?.config.content_markdown || 'Participation is voluntary and anonymous.'),
      requireCheckbox: dsl.consent_settings.require_checkbox ?? true,
      minAge: dsl.consent_settings.minimum_age ?? 18,
      instructionTitle: instructionNode?.config.title || 'Experiment Instructions',
      instructionContent: instructionNode?.config.content_markdown || 'Respond to stimuli as rapidly and accurately as possible.',
      continueButtonText: instructionNode?.config.continue_button_text || 'Start Experiment',
      allowedKeys,
      responseDeadlineMs: responseNode?.config.deadline_ms || 1500,
      fixationDurationMs: fixationNode?.config.duration_ms || 500,
      fixationJitterMs: fixationNode?.config.jitter_ms || 150,
      itiDurationMs: itiNode?.config.duration_ms || 350,
      trials,
      gameSkinEnabled: dsl.game_skin.enabled,
      soundEnabled: dsl.game_skin.sound_enabled ?? true,
      scoreRules: {
        basePoints: rewardNode?.config.points || dsl.game_skin.score_rules.correct_base_points || 100,
        streakMultiplier: dsl.game_skin.score_rules.streak_bonus_multiplier || 1.25,
      },
      debriefTitle: debriefNode?.config.title || 'Session Complete',
      debriefContent: debriefNode?.config.content_markdown || 'Thank you for your participation!',
    };
  }
}
