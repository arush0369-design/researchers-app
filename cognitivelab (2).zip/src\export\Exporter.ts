import { TrialRecord, ExperimentDSL } from '../types/dsl';

export class Exporter {
  /**
   * Safely quotes a CSV field: escapes embedded double-quotes by doubling
   * them (the RFC 4180 convention) so that stimulus text, conditions, or
   * IDs containing commas, quotes, or newlines don't corrupt the file.
   */
  private static csvField(value: string | number): string {
    const str = String(value);
    return `"${str.replace(/"/g, '""')}"`;
  }

  /**
   * Generates Hadley Wickham's Tidy Long Format CSV (1 row = 1 trial)
   */
  public static generateLongCSV(trials: TrialRecord[], experiment: ExperimentDSL): string {
    const headers = [
      'session_id',
      'trial_index',
      'experiment_id',
      'experiment_version',
      'condition',
      'stimulus',
      'response_key',
      'expected_key',
      'is_correct',
      'reaction_time_ms',
      'frame_onset_ts',
      'display_lag_ms',
      'score',
      'streak',
      'quality_flags',
      'timestamp'
    ];

    const rows = trials.map((t) => [
      this.csvField(t.sessionId),
      t.trialIndex,
      this.csvField(experiment.experiment.id),
      experiment.experiment.version,
      this.csvField(t.condition),
      this.csvField(t.stimulus),
      t.responseKey ? this.csvField(t.responseKey) : 'NA',
      this.csvField(t.expectedKey),
      t.isCorrect === null ? 'NA' : t.isCorrect ? 'TRUE' : 'FALSE',
      t.reactionTimeMs !== null ? t.reactionTimeMs.toFixed(2) : 'NA',
      t.frameOnsetTs ? t.frameOnsetTs.toFixed(2) : 'NA',
      t.displayLagMs ? t.displayLagMs.toFixed(2) : 'NA',
      t.score ?? 0,
      t.streak ?? 0,
      this.csvField(t.qualityFlags && t.qualityFlags.length > 0 ? t.qualityFlags.join(';') : 'NONE'),
      this.csvField(t.timestamp)
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  /**
   * Generates Participant-Level Summary CSV (1 row = 1 session)
   * Dynamically adapts to ANY condition names in the dataset!
   */
  public static generateWideCSV(trials: TrialRecord[], experiment: ExperimentDSL): string {
    if (trials.length === 0) {
      return 'session_id,experiment_id,version,total_trials,completed,total_score,mean_rt_overall,median_rt_overall,acc_overall,flagged_trials_count';
    }

    // Discover all unique conditions
    const allConditions = Array.from(new Set(trials.map((t) => t.condition))).sort();

    // Group trials by session
    const sessions = new Map<string, TrialRecord[]>();
    trials.forEach((t) => {
      const list = sessions.get(t.sessionId) || [];
      list.push(t);
      sessions.set(t.sessionId, list);
    });

    // Build dynamic header
    const headers = [
      'session_id',
      'experiment_id',
      'version',
      'total_trials',
      'completed',
      'total_score',
      'mean_rt_overall',
      'median_rt_overall',
      'acc_overall',
      ...allConditions.map((c) => `mean_rt_${c}`),
      ...allConditions.map((c) => `acc_${c}`),
      'flagged_trials_count'
    ];

    const rows: string[][] = [];

    sessions.forEach((sTrials, sId) => {
      const validRTs = sTrials.filter((t) => t.reactionTimeMs !== null).map((t) => t.reactionTimeMs!);
      const meanRT = validRTs.length ? validRTs.reduce((a, b) => a + b, 0) / validRTs.length : 0;

      const sortedRTs = [...validRTs].sort((a, b) => a - b);
      const medianRT = sortedRTs.length ? sortedRTs[Math.floor(sortedRTs.length / 2)] : 0;

      const correctCount = sTrials.filter((t) => t.isCorrect).length;
      const accOverall = sTrials.length ? (correctCount / sTrials.length) * 100 : 0;

      // Condition metrics dynamically
      const conditionRTs = allConditions.map((cond) => {
        const cTrials = sTrials.filter((t) => t.condition === cond && t.reactionTimeMs !== null);
        if (cTrials.length === 0) return 'NA';
        const sum = cTrials.reduce((a, b) => a + b.reactionTimeMs!, 0);
        return (sum / cTrials.length).toFixed(2);
      });

      const conditionAccs = allConditions.map((cond) => {
        const cTrials = sTrials.filter((t) => t.condition === cond);
        if (cTrials.length === 0) return 'NA';
        const cCorrect = cTrials.filter((t) => t.isCorrect).length;
        return ((cCorrect / cTrials.length) * 100).toFixed(1);
      });

      const lastTrial = sTrials[sTrials.length - 1];
      const flagged = sTrials.filter((t) => t.qualityFlags && t.qualityFlags.length > 0).length;

      rows.push([
        this.csvField(sId),
        this.csvField(experiment.experiment.id),
        `${experiment.experiment.version}`,
        `${sTrials.length}`,
        'TRUE',
        `${lastTrial ? lastTrial.score : 0}`,
        meanRT.toFixed(2),
        medianRT.toFixed(2),
        accOverall.toFixed(1),
        ...conditionRTs,
        ...conditionAccs,
        `${flagged}`
      ]);
    });

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  /**
   * Directly triggers download of Long CSV
   */
  public static downloadLongCSV(trials: TrialRecord[], experiment: ExperimentDSL, filename?: string): void {
    const content = this.generateLongCSV(trials, experiment);
    this.downloadFile(filename || `${experiment.experiment.slug || 'experiment'}_trials_long.csv`, content, 'text/csv;charset=utf-8;');
  }

  /**
   * Directly triggers download of Wide CSV
   */
  public static downloadWideCSV(trials: TrialRecord[], experiment: ExperimentDSL, filename?: string): void {
    const content = this.generateWideCSV(trials, experiment);
    this.downloadFile(filename || `${experiment.experiment.slug || 'experiment'}_sessions_wide.csv`, content, 'text/csv;charset=utf-8;');
  }

  /**
   * Helper to trigger download of string content
   */
  public static downloadFile(filename: string, content: string, mimeType: string): void {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
