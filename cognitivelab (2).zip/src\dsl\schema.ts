import { z } from 'zod';

export const ExperimentMetadataSchema = z.object({
  id: z.string().min(1, 'Experiment ID is required'),
  slug: z.string().min(1, 'Slug is required'),
  version: z.number().int().positive(),
  title: z.string().min(1, 'Title is required'),
  description: z.string(),
  created_at: z.string(),
  author: z.object({
    user_id: z.string(),
    institution: z.string(),
  }),
  reproducibility: z.object({
    dsl_version: z.string(),
    target_runtime: z.string(),
    hash_sha256: z.string().optional(),
  }),
});

export const ParticipantSettingsSchema = z.object({
  allow_anonymous: z.boolean(),
  enforce_fullscreen: z.boolean(),
  minimum_display_hz: z.number().min(30).max(360),
  device_allowlist: z.array(z.string()),
  required_inputs: z.array(z.string()),
});

export const ConsentSettingsSchema = z.object({
  required: z.boolean(),
  ethics_protocol_id: z.string(),
  statement_text: z.string().min(10, 'Informed consent statement must be detailed'),
  require_checkbox: z.boolean(),
  minimum_age: z.number().int().min(0),
});

export const DSLNodeSchema = z.object({
  id: z.string().min(1),
  type: z.enum([
    'flow_start',
    'flow_end',
    'presentation_text',
    'presentation_fixation',
    'presentation_stimulus',
    'response_keyboard',
    'logic_condition',
    'logic_loop',
    'randomization_balanced_block',
    'game_reward',
    'timing_wait',
    'timing_calibration',
    'data_record_trial'
  ]),
  label: z.string(),
  config: z.record(z.any()),
  position: z.object({ x: z.number(), y: z.number() }).optional(),
});

export const DSLEdgeSchema = z.object({
  id: z.string().min(1),
  from: z.string().min(1),
  to: z.string().min(1),
  port: z.string().optional(),
  label: z.string().optional(),
});

export const ExperimentDSLSchema = z.object({
  $schema: z.string().optional(),
  experiment: ExperimentMetadataSchema,
  participant_settings: ParticipantSettingsSchema,
  consent_settings: ConsentSettingsSchema,
  variables: z.record(
    z.object({
      type: z.enum(['string', 'number', 'boolean']),
      default: z.any(),
      scope: z.enum(['global', 'trial']),
    })
  ),
  game_skin: z.object({
    enabled: z.boolean(),
    theme: z.enum(['deep-space-arcade', 'academic-clean', 'retro-synth']),
    sound_enabled: z.boolean(),
    hud_elements: z.object({
      show_score: z.boolean(),
      show_streak: z.boolean(),
      show_progress_bar: z.boolean(),
    }),
    score_rules: z.object({
      correct_base_points: z.number(),
      streak_bonus_multiplier: z.number(),
      incorrect_penalty: z.number(),
      max_rt_for_bonus_ms: z.number(),
    }),
  }),
  nodes: z.array(DSLNodeSchema).min(2, 'Experiment must contain at least start and end nodes'),
  edges: z.array(DSLEdgeSchema),
});
